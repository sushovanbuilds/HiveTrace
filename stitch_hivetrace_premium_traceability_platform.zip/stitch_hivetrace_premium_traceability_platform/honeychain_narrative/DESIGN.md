---
name: HoneyChain Narrative
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#514532'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#837560'
  outline-variant: '#d5c4ab'
  surface-tint: '#7c5800'
  primary: '#7c5800'
  on-primary: '#ffffff'
  primary-container: '#ffb800'
  on-primary-container: '#6b4c00'
  inverse-primary: '#ffba20'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2dfde'
  on-secondary-container: '#636262'
  tertiary: '#3b6934'
  on-tertiary: '#ffffff'
  tertiary-container: '#9fd292'
  on-tertiary-container: '#2e5b28'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdea8'
  primary-fixed-dim: '#ffba20'
  on-primary-fixed: '#271900'
  on-primary-fixed-variant: '#5e4200'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#bcf0ae'
  tertiary-fixed-dim: '#a1d494'
  on-tertiary-fixed: '#002201'
  on-tertiary-fixed-variant: '#23501e'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-hero:
    fontFamily: Geist
    fontSize: 72px
    fontWeight: '700'
    lineHeight: 80px
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Geist
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  metadata-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1440px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 64px
  stack-sm: 4px
  stack-md: 16px
  stack-lg: 48px
---

## Brand & Style

The design system is engineered for a premium enterprise environment where transparency and heritage meet technological precision. The brand personality is authoritative yet inviting, blending the warmth of honey production with the cold accuracy of blockchain traceability.

The aesthetic follows a **Modern Enterprise** approach, heavily influenced by the high-fidelity layering found in modern productivity tools and luxury fintech. Key characteristics include:
- **Sophisticated Glassmorphism:** Using depth and backdrop blurs to signify hierarchy rather than heavy shadows.
- **Precision Alignment:** A rigorous adherence to grid systems to convey a sense of reliability and enterprise-grade security.
- **Generous Whitespace:** Promoting focus on high-value data points and reducing cognitive load during complex supply chain audits.
- **Atmospheric Depth:** Utilizing light-on-dark and dark-on-light layering to create a sense of physical space within the digital interface.

## Colors

The palette is anchored by the **Warm Honey (#FFB800)** primary accent, used purposefully to draw attention to status indicators and primary actions. 

- **Background Strategy:** Use the warm off-white (#FAFAFA) as the base foundation. Surface areas use pure white or high-transparency glass layers.
- **Surface Contrast:** Soft charcoal (#1A1A1A) is reserved for high-contrast sidebars, global navigation, or "Deep Mode" data visualizations to provide a premium, weighted feel.
- **Functional Accents:** Botanical green is used strictly for "Verified" statuses and growth metrics. Red is used sparingly in a desaturated, "Restrained Red" tone to indicate supply chain breaks or alerts without inducing panic.
- **Transparency:** Use `glass_white` with a `20px` backdrop blur for floating panels and modals to maintain context of the underlying data.

## Typography

This design system utilizes a dual-font strategy to balance impact with utility. 

- **Display & Headlines:** Use **Geist** for its technical precision and tight kerning. Large headlines should use negative letter-spacing to achieve the "Linear" aesthetic.
- **Body Text:** Use **Inter** for all long-form data and interface labels. It provides the necessary legibility for complex supply chain manifests.
- **Metadata:** Compact metadata levels use **Geist** in uppercase with slight tracking (letter-spacing) to create a distinct visual "stamp" for verified IDs and timestamps.
- **Hierarchy:** Maintain a massive delta between headlines and body text to enforce a clear narrative path.

## Layout & Spacing

The layout philosophy is built on a **Fixed-Fluid Hybrid Grid**. Content is centered within a maximum container width of 1440px to ensure readability on ultra-wide monitors common in enterprise settings.

- **Grid Model:** A 12-column grid with generous 24px gutters. Elements should generally span 3, 4, 6, or 12 columns.
- **Rhythm:** Use an 8px base unit. Vertical rhythm should favor "Stack" spacing (48px) between major sections to emphasize the premium, airy feel.
- **Alignment:** Align text strictly to the left. Avoid center-alignment for anything other than hero marketing sections. In data tables, use tabular figures for numerical alignment.
- **Mobile Adaption:** On mobile, margins shrink to 20px, and the 12-column grid collapses to a single column. Horizontal scrolling is permitted for data-heavy tables to maintain column integrity.

## Elevation & Depth

Elevation is achieved through **Tonal Layering** and **Subtle Glass effects** rather than traditional shadows.

- **The Base (Level 0):** The #FAFAFA background.
- **The Surface (Level 1):** Solid white or charcoal containers with a 1px border (#000 at 0.06% opacity). No shadow.
- **The Float (Level 2):** Modal windows or dropdowns. Use `glass_white` with a `20px` blur and a very soft, high-diffusion shadow (0px 20px 40px rgba(0,0,0,0.04)).
- **The Active (Level 3):** Primary buttons or selected states. These use the Honey (#FFB800) color to "pop" forward from the muted background layers.

## Shapes

The design system employs a **Large Controlled Radius** strategy. 

- **Primary Containers:** Cards and main surface areas use a 16px radius (`rounded-lg`). 
- **Large Sections:** Hero areas or feature blocks use a 24px radius (`rounded-xl`).
- **Interactive Elements:** Buttons and input fields use a consistent 8px radius to feel precise and mechanical.
- **Borders:** Always use 1px width. Borders should be slightly darker than the surface they sit on to provide definition without breaking the minimal aesthetic.

## Components

### Buttons
- **Primary:** Solid #FFB800 with #1A1A1A text. 8px radius. No shadow, but a subtle inner-glow on hover.
- **Secondary:** Transparent background with 1px #1A1A1A border. 
- **Ghost:** No border, Geist font, uppercase metadata style.

### Cards
- Use white backgrounds with 1px subtle borders. 
- Header areas within cards should have a light grey (#F1F1F1) bottom stroke.
- Padding should be generous (32px) to prevent data from feeling cramped.

### Input Fields
- Soft grey background (#F5F5F5) that turns white on focus.
- 1px border that shifts from subtle to charcoal on focus.
- Label text uses the `label-caps` typography style.

### Chips & Status Indicators
- Use a "Dot + Label" system.
- "Verified" uses a subtle botanical green background (10% opacity) with solid green text and a 2px green dot.
- Honey batches use a primary amber pill shape.

### Supply Chain Timeline
- A bespoke component featuring a vertical or horizontal thin line (1px) with hollow nodes. 
- Active nodes fill with #FFB800.
- Use Geist Mono for batch numbers and SKU tracking within the timeline.